# Next steps before October 19 morning

1. Run notebooks/02_mapping_audit.ipynb in Colab on six cases, review errors/configurations, then run 40 cases. Upload official_audit_outputs.zip for integration.
2. Confirm original FICO code dictionary. Audit categorical status handling and candidate reason labels; no numerical ordinal assumption about -7/-8/-9.
3. Check redistribution permissions before publishing case-profile values or dataset-derived exports. Raw CSV is omitted from the deliverable ZIP.
4. Review taxonomy rationale: signed grouping can cancel effects, has fewer categories and varying list sizes. Add fixed-list-length/top-one comparisons before making stronger claims.
5. Evaluate whether ±1 ratio point probes are financially defensible. Current results are measurement sensitivity, not feasible recourse. Do not claim the broader perturbation audit is complete.
6. Inspect website in a real browser on desktop/mobile; merge into GitHub after inspecting existing repository contents.
7. Replace the reference-pilot poster with official findings, final title/author details, reviewed citations and limitations. Confirm poster printing deadline now.
