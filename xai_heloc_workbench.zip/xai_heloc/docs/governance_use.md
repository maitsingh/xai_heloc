# Using the workbench in an adverse-action evidence review

## Audience and purpose
A proposed research aid for lender compliance teams, independent model validators, governance personnel and, where the institution falls within their jurisdiction, supervisory reviewers. The current data are a public benchmark, not a lender examination sample. No agency adoption, endorsement or production readiness is claimed.

## What a CFPB reviewer could do with a lender-adapted version
Use actual sampled loan files and contemporaneous model/notice records, identify inconsistent or insufficiently detailed candidate reasons, then ask the lender for the relevant configuration, validation and mapping evidence. This is a proposed investigation workflow. CFPB procedures do not prescribe this tool or a stability cutoff.

The July 2026 CFPB ECOA examination procedures, Notifications (Procedures pp. 17–19), address review of notification policies, files, audits and required notice elements. Regulation B's official interpretation at 9(b)(2) addresses the relation between disclosed reasons and factors considered/scored. These support a focus on documentary evidence and actual decision factors, not an automated compliance score.

## What happens in this project
1. A classifier predicts the supplied dataset's repayment-performance classes, “Bad” and “Good”. It does not observe an actual creditor decision.
2. A research score cutoff of 0.50 creates simulated rejections. It is not a documented underwriting policy or legal standard.
3. Exact empirical interventional Shapley calculations allocate score differences relative to a fixed reference. A custom LIME-style surrogate estimates local behavior. Official SHAP/LIME reproduction remains pending.
4. Repeat explanations on identical inputs; inspect recorded +/-1-point ratio changes where the simulated rejection is unchanged and score change is <=0.02. These are measurement tests, not validated borrower actions.
5. Map features into illustrative broad categories by signed sums. Compare feature and category lists. Neither mapping is legally approved notice wording.
6. Convert findings into evidence requests, suggested responsible roles and review notes. Export a JSON record; no legal pass/fail is produced.

## Reviewer workflow in the revised site
Read Purpose & review steps. Inspect stated reasons for a selected record. Compare audit findings across experiments. Open Evidence & follow-up, select the model and a provisional turnover trigger, inspect six results-linked findings, record documents reportedly supplied, add notes and export the review.

Document checkboxes only record reviewer statements; they do not validate supplied evidence. Technical tolerance satisfaction cannot establish actual principal-reason accuracy, notice timing or content, FCRA applicability, NC coverage or fair lending.

## Why the original assurance ledger was inadequate
It was a static source map with manually assigned statuses. It did not consume selected results, identify the evidence supporting each finding, request concrete additional documents, assign a review role or produce a decision record. A source list is useful, but is not an assurance assessment.

The revised view computes repeatability flags from recorded findings, counts method disagreement hidden by grouping, identifies excluded no-record profiles and distinguishes those from unresolved fidelity and process evidence. It states what to investigate and what cannot be concluded.

## Policy and research reading guide
- CFPB ECOA examination procedures, July 2026: Notifications, Procedures pp. 17–19. https://files.consumerfinance.gov/f/documents/cfpb_ecoa-narrative-and-procedures_2026-07.pdf
- Regulation B official interpretation, 9(b)(2), comments 1–5 and 9: actual factors, reason-selection methods and ECOA/FCRA distinctions. https://www.consumerfinance.gov/rules-policy/regulations/1002/interp-9/
- FinRegLab, Explainability & Fairness in Machine Learning for Credit Underwriting: Policy Analysis (2023), Sections 4.2.2 and 5.1.3–5.2.1: conceptual soundness, reason-code aggregation and disclosure reliability. https://finreglab.org/research/explainability-fairness-in-machine-learning-for-credit-underwriting-policy-analysis/
- Nair et al., Explaining Adverse Actions in Credit Decisions Using Shapley Decomposition (2022): technical reference choice and correlated predictors. https://arxiv.org/abs/2204.12365
- OpenXAI (2022): established evaluation concepts; stability is distinct from faithfulness and fairness. https://zitniklab.hms.harvard.edu/publications/papers/OpenXAI-NeurIPS22.pdf
- North Carolina G.S. 75-1.1: unfair/deceptive-practice context, requiring separate legal applicability analysis. https://www.ncleg.gov/EnactedLegislation/Statutes/HTML/BySection/Chapter_75/GS_75-1.1.html

Reviewed October 14, 2026. CFPB Circular 2022-03 is withdrawn, not current binding authority. This is an initial reading guide, not an exhaustive legal memorandum.
