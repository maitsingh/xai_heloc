# Legal scope and evidence boundaries

Preliminary source review dated October 14, 2026. This is a research assurance aid, not a legal opinion or compliance certification. Sources are linked in legal_evidence.json.

Regulation B requires specific principal reasons; its interpretation concerns factors actually considered/scored and does not equate generic credit-score factors with the reasons for the creditor decision. Four-feature lists are a research convention, not a requirement to report exactly four reasons. Review wording and candidate-reason mapping before presenting consumer-like notices.

FCRA applies conditionally based on consumer-report and credit-score use. FTC guidance supplies an entry point; primary statutory text and applicable interpretation must be reviewed before marking elements satisfied.

North Carolina G.S. 75-1.1 addresses unfair/deceptive practices. No explanation-stability threshold is established by that text. Applicable NC product, lender, exemption and federal-preemption issues remain pending. Chapter 24 is an applicability research source, not a blanket claim that every provision applies to a HELOC. The dataset does not establish NC residency.

Fair lending, record retention, privacy, mortgage-specific disclosures, charter-specific supervision and notice delivery are separate research tracks or outside experimental scope. Missing protected attributes prevent a full fair-lending assessment. Do not present absence of tested discrimination as evidence of compliance.
