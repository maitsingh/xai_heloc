# Reference pilot findings

All numbers below derive from results/reference/audit_results.json. Exact empirical interventional Shapley and a CUSTOM local surrogate were used; official LIME/SHAP reproduction remains pending.

Primary model test ROC AUC: 0.7709; with external-score model: 0.7821. No causal performance conclusion or calibrated-probability claim follows.

In 40 selected held-out simulated rejections, mean within-applicant pairwise custom-surrogate reason-membership turnover was 34.25% at feature level and 19.75% after grouping. Five runs provide ten seed pairs per applicant. The statistic is NOT the percentage of applicants whose lists ever changed. Grouping has fewer possible categories and variable list lengths, so lower turnover may arise mechanically.

Between exact Shapley and the custom surrogate, individual membership differed in 24/40 cases; grouped membership differed in 16/40. In 11/40 cases, individual sets differed while grouped sets matched. This is a descriptive masked-disagreement observation, not validation of either explanation.

Primary-model +/-1 ratio-point tests accepted 137/160 candidates across 39 applicants. Reasons for exclusion: special states, observed-range guard, changed decision, and score movement. These are measurement-sensitivity probes, not validated feasible borrower actions. Filtering can favor stable cases; exclusion counts are always shown.

Applicant 9178 illustrates identical-input seed differences: seed 0 includes never-delinquent share, seed 1 includes oldest account age. Both map to the same set of broad categories, although their category ranking changes. The dashboard distinguishes membership from ranking.

## Assurance implications
Broad category stability is insufficient evidence of feature-level consistency or specificity. Stable identical inputs do not establish fidelity. Near-tied ranked values warrant inspection rather than an automatic failure label. Method disagreement may reflect different explanation questions. User-facing reason language and principal-reason adequacy remain unvalidated.

## Remaining work before final submission
Official-library run in Colab; original code dictionary and usage-term verification; stronger realism checks; tolerance sensitivity; mapping justification and list-cardinality-controlled analysis; independent assessment of candidate reason descriptions; final legal source and applicability review. No-record and demographic coverage limits must remain visible.
