# Audit protocol version 0.1

## Scope
Hypothetical US consumer creditor considering a HELOC application by a North Carolina resident. Lender charter, regulator, real-property facts and source of consumer-report information remain unspecified. No actual lending occurs. NC residence is a scenario assumption, not a dataset field.

## Question
How repeatable and locally stable are SHAP and LIME attribution reason lists, and what evidence remains necessary before consumer-facing use?

## Design
1. Freeze dataset checksum, dictionary, preprocessing, split and model configuration.
2. Evaluate discrimination and calibration separately; do not tune on audit cases.
3. Select up to 60 held-out simulated rejections, balancing near/far threshold strata where available. Report exclusions and available counts.
4. Same-input test: five distinct recorded LIME seeds; deterministic SHAP configuration and fixed background.
5. Perturbation test: only validated feature transformations. Retain unchanged simulated decisions with absolute score change <=0.02. This research tolerance is not a legal standard. Show sensitivity to alternative tolerances.
6. Cross-method comparison: fixed class, documented output scales and distinct explanation semantics; LIME discretized conditions are not equivalent to global SHAP feature effects.
7. Record attempted, invalid, decision-changing, score-filtered and accepted perturbations. Report survival rates so filtering cannot hide instability.
8. Analyze reason retention, Jaccard, first-reason changes, attribution gaps, sign changes where comparable, LIME local fit and SHAP reconstruction residual.

## Interpretation
Top-four membership is sensitive to near ties. For lists shorter than four, use explicit actual-length denominators; zero-positive-feature cases are not silently treated as stable. Confidence intervals must respect dependence within applicants; multiple perturbations are not independent applicants.

## Assurance statuses
Evidence supports a narrow criterion; investigate; insufficient evidence; outside scope; applicability unresolved. No numeric aggregate compliance score. Separate observed measurements from adjustable research tolerances and institutional judgments.

## Poster schedule
October 14: methods poster and data verification. October 15: baseline and repeatability pilot. October 16: validated perturbations and frozen protocol. October 17: final runs and analysis. October 18: final poster, site and reproducibility check. October 19 morning: submission. User should confirm printing cutoff immediately; draft cannot substitute for final findings.
