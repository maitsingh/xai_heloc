# Verification record

- Raw CSV hash matches metadata supplied in user ZIP. Original-provider dictionary and redistribution terms remain unverified.
- Reference experiment completed: two Random Forest models; 40 primary cases and 32 common rejected cases for the score-added model.
- Five meaningful analytical/boundary tests passed: known additive Shapley, distinct special-state encoding, signed group cancellation, empty-list handling, distinct overlap denominators.
- HTML scripts and navigation/control handlers passed a simulated-DOM smoke check. A browser executable is unavailable here: visual browser QA and responsive rendering remain unverified.
- Poster was rendered to PNG and visually reviewed; dimensions 36 x 24 inches.
- Notebook code cells parse. Official package execution remains pending in Colab.
- No remote repository inspection, push, or deployment took place.

Governance revision: model-dependent evidence findings, review-tolerance changes, reviewer-reported document states, and unchanged unresolved legal conclusion passed simulated-DOM checks. Browser visual QA remains pending. Poster wording was updated and its rendered page reviewed.
