from pathlib import Path
import json
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import simpleSplit
R=Path(__file__).resolve().parents[1]
pdfmetrics.registerFont(TTFont('Sans','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('SansBold','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
d=json.loads((R/'results/reference/audit_results.json').read_text())
C=canvas.Canvas(str(R.parent/'heloc_reference_poster.pdf'),pagesize=(2592,1728))
C.setTitle('Same Decision Different Reasons - Reference Pilot')
INK='#203f51';ORANGE='#bc4d22';MUTED='#64717a';BG='#f6f4ef';LINE='#deded6'
def text(x,y,s,size=24,color=INK,bold=False):
 C.setFillColor(HexColor(color));C.setFont('SansBold' if bold else 'Sans',size);C.drawString(x,y,s)
def para(x,y,s,width,size=24,color=INK,leading=None):
 lines=simpleSplit(s,'Sans',size,width);leading=leading or size*1.4
 for i,line in enumerate(lines):text(x,y-i*leading,line,size,color)
 return y-len(lines)*leading

def box(x,y,w,h,color='#ffffff'):
 C.setFillColor(HexColor(color));C.roundRect(x,y,w,h,12,fill=1,stroke=0)
def bar(x,y,label,value,width=600,color=INK):
 text(x,y,label,24);C.setFillColor(HexColor('#e9ece7'));C.roundRect(x,y-43,width,20,4,fill=1,stroke=0)
 C.setFillColor(HexColor(color));C.roundRect(x,y-43,width*value,20,4,fill=1,stroke=0)
 text(x+width+18,y-40,f'{value*100:.2f}%',26,color,True)
C.setFillColor(HexColor(BG));C.rect(0,0,2592,1728,fill=1,stroke=0)
text(60,1660,'EXPLANATION ASSURANCE  /  RESPONSIBLE AI  /  US CONSUMER CREDIT',22,ORANGE,True)
text(60,1555,'Same Decision, Different Reasons',83,INK,True)
para(60,1494,'Do broader credit-denial reasons conceal changes in the evidence behind them?',2440,35)
text(60,1400,'REFERENCE PILOT: exact interventional Shapley + custom LIME-style surrogate. Official-library reproduction pending.',24,ORANGE,True)
# Main exhibit spans two columns.
box(60,775,1590,570)
text(95,1290,'ONE APPLICANT. IDENTICAL INPUT. DIFFERENT RANDOM SEEDS.',23,ORANGE,True)
c=next(c for c in d['cases'] if c['case_id']==9178 and c['model']=='without_score');runs=c['explanations']['Custom LIME-style surrogate']
text(95,1225,f'Applicant 9178  |  Model score {c["score"]:.3f}  |  Simulated denial unchanged',29,INK,True)
for i,seed in enumerate([0,1]):
 x=95+i*780;text(x,1162,f'Individual features / seed {seed}',28,INK,True)
 for j,reason in enumerate(runs[seed]['individual']):
  is_change=j==3;text(x,1103-j*51,f'{j+1}. {reason["label"]}',27,ORANGE if is_change else INK,bold=is_change)
 text(x,866,'Mapped set: repayment history, revolving balances, inquiries',18,MUTED)
text(95,805,'Feature membership changes; grouped membership matches. Category ranking still changes.',23,ORANGE,True)
# Right evidence area.
box(1690,775,842,570)
text(1730,1290,'A FINDING TO INVESTIGATE',23,ORANGE,True)
text(1730,1190,'34.25% → 19.75%',69,INK,True)
para(1730,1130,'Mean pairwise reason turnover across five custom-surrogate seeds: individual features versus grouped categories.',745,26)
text(1730,961,'11 / 40',57,ORANGE,True)
para(1730,910,'Cases where the two methods disagree at feature level but match after grouping. Matching categories does not validate either explanation.',740,25)
# Lower three panels.
box(60,295,790,440);box(890,295,790,440);box(1720,295,812,440)
text(95,677,'01 / WHAT WAS EVALUATED',23,ORANGE,True)
para(95,629,'40 held-out simulated rejections; five surrogate seeds; eight predictors. Fixed background for exact Shapley. A second model adds the external risk score.',710,25)
para(95,474,'Preserve distinct special states. Quarantine 588 no-record rows. Keep identical predictor profiles in the same split. Test ROC AUC: 0.771 without external score.',710,25)
text(925,677,'02 / TURNOVER AFTER GROUPING',23,ORANGE,True)
bar(925,622,'Individual reasons',.3425,580,INK)
bar(925,522,'Grouped categories',.1975,580,ORANGE)
para(925,420,'Turnover: at least one reason added or removed. Fewer categories can mechanically improve agreement. Lower turnover alone does not establish more accurate or specific reasons.',700,22)
text(1755,677,'03 / REVIEWER FOLLOW-UP',23,ORANGE,True)
para(1755,625,'Request the reason-mapping rules, the underlying decision record and independent validation. Matching broad labels can conceal disagreement about individual factors.',735,25)
para(1755,465,'Regulation B concerns specific principal reasons tied to actual decision factors. This pilot flags review questions; it cannot establish notice accuracy, legal sufficiency or NC coverage.',735,24)
# Bottom limitation ribbon, sources small but readable at full size.
C.setFillColor(HexColor(INK));C.rect(0,115,2592,140,fill=1,stroke=0)
para(60,211,'LIMITS  /  Custom surrogate, not official LIME. Coalition replacements can break dependencies. Ratio changes test measurement sensitivity, not feasible borrower actions. Selected cases are not population-representative. No notice, fairness or compliance certification.',2470,23,'#ffffff',32)
text(60,76,'Sources: OpenXAI (2022); XAI Stories HELOC; Interpretable AI FICO tutorial; FinRegLab (2023); Regulation B 1002.9 and interpretation; NC G.S. 75-1.1.',17,MUTED)
text(60,43,'github.com/maitsingh/xai_heloc  |  Full evidence and configurations in workbench  |  Recorded pilot: 14 October 2026  |  Poster: 36 x 24 inches',17,MUTED)
C.save()
print(R.parent/'heloc_reference_poster.pdf')
